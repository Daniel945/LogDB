/*
 * main.h
 *
 *  Created on: Feb 10, 2014
 *      Author: hadoop
 */


#ifndef MAIN_H_
#define MAIN_H_

//#define append(a,b) _append(&a,sizeof(a),&b,sizeof(b))		//宏定义进行替换，实现获得变量大小。
															//sizeof(a)能获取char[]a="1"为2，char[]a={'a'}为1
															//char*a="1"为4，即指针大小，此处不正确

#define next(a,b) _next(&a, &b)
#define get(a,b) _get(&a,&b)
//#define search(a,b) _search(&a,&b)
//#define LONG_MAX 2147483647
#define _FILE_OFFSET_BITS 64
#define longestValue 2048
//long long offsetFu[1000000];
//int x[1000000];
//int tim;

extern int keyType, valType;

extern int INTERVAL;

#define INT 1
#define DOUBLE 2
#define STRING 3

extern const int headSize;

extern void** index_buf;
extern long long* index_key;
extern int indexSize;

//extern unsigned long index_filesize;

extern int fp_w, fp_r;

extern int setup_flag;

char fileAddr[100];
char indexAddr[100];

int openFile(const char *file);

//void setup(const char* Daddr,const char* Iaddr);
void readHead();
void rewind_Read();
void cont_start(const int fp);
int _next(void* key, void* value);
int util_next(void* key, void* value ,int* keySize, int* pairSize);
int _append(void* key,int keySize,void* value,int valueSize);
int _get(void* key,void* value);
int _search(void* key, void* value);
int compare(void* mid, void* key);
void find(void* key, long long* offset);

int build_Index();
int load_Index();
int openExistedFile(const char *file);
int setIndexPath(const char* path);
#endif /* MAIN_H_ */
