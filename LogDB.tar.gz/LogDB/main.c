#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<malloc.h>
#include<sys/time.h>
#include<sys/stat.h>
#include<unistd.h>
#include<time.h>
#include"main.h"

#include <Python.h>

void writeTest(){
//	write(fp_w, &INT, sizeof(int));
//	write(fp_w, &STRING, sizeof(int));

	int dd=0;
	int key1=1;
	char value1[112];			//char *value="aaa","aaa"放在常量区，value指向它，所以其指向值不可修改
	for(dd=0;dd<111;dd++) value1[dd]='a'+dd%26;
	value1[111] = '\0';
//	printf("%s\n",value1);
	int i,j;

	struct timeval start,end;
	long long cost = 0;
	for(j=0;j<1;j++){
		gettimeofday(&start,NULL);
		for(i=0;i<4000000;i++){
			append(key1,value1);
			key1++;
			if(i%400000==0) {printf("complete %i percent\n", i/40000);}
		}
		gettimeofday(&end,NULL);
		cost = ((long long)1000000*end.tv_sec+end.tv_usec) - ((long long)1000000*start.tv_sec+start.tv_usec);
		printf("%i\n",end.tv_sec-start.tv_sec);
		printf("%lld\n",cost/4000000);
	}



/*
	int keyR1;
	char valueR1[50]={'\0'};

	rewind_Read();
	int ret;
	while(1){
		ret = next(keyR1,valueR1);
		if(-1 == ret || 0 == ret) break;
		printf("%i %s \n",keyR1,valueR1);
	}
*/

}

void readWithoutIndex(int x,int i){
	char xx[50] = {'\0'};
//	lseek(fp_r,offsetFu[i],SEEK_SET);
	char tmp[50]={'\0'};
	char tmpVal[50]={'\0'};
	int keyS,pairS;
	while(util_next(tmp,tmpVal,&keyS,&pairS)){
		if( memcmp(tmp,&x,keyS)==0 ){
			memcpy(xx,tmpVal,pairS-keyS);
			break;
		}
		if(compare(tmp,&x)>0) break;
//		printf("key:%i tmp:%i\n",x,*(int*)tmp);
	}
}

void readTest(){
	load_Index();

	char xx[200]={'0'};//change to test
	int times=10000;
//	int x[times];

	struct timeval start,end;
	long long cost;
	int w,k;

	srand(time(NULL));
	for(k=0;k<times;k++)
		x[k] = (rand()/(double)RAND_MAX)*40000000;

	gettimeofday(&start,NULL);
	for(w=0;w<times;w++){
		search(x[w],xx);
//		printf("%s\n",xx);
		if(w%1000==0) {printf("complete %i percent\n", w/1000);}
	}
	gettimeofday(&end,NULL);
	cost = ((long long)1000000*end.tv_sec+end.tv_usec) - ((long long)1000000*start.tv_sec+start.tv_usec);
	printf("first %lld\n",cost/times);

	int i;
	srand(time(NULL));
	for(k=0;k<times;k++)
			x[k] = (rand()/(double)RAND_MAX)*40000000;
	gettimeofday(&start,NULL);
	for(i=0;i<times;i++){
//		readWithoutIndex(x[i],i);
		search(x[i],xx);
	}
	gettimeofday(&end,NULL);
	cost = ((long long)1000000*end.tv_sec+end.tv_usec) - ((long long)1000000*start.tv_sec+start.tv_usec);
	printf("second %lld\n",cost/times);


}


int main(){
/*	const char *fileAddr = "/home/hadoop/workspace/LogDB/myFile";
	const char *indexAddr = "/home/hadoop/workspace/LogDB/myIndex";
	setup(fileAddr,indexAddr);
	writeTest();*/
	char aaa[] = "dfd";
	setFilePath(aaa);
//	build_Index();
//	readTest();
//	close(fp_w);
//	close(fp_r);
	return 0;
}

/*static PyObject* invokeDB(){
	const char *fileAddr = "/home/hadoop/workspace/LogDB/myFile";
	const char *indexAddr = "/home/hadoop/workspace/LogDB/myIndex";
	setup(fileAddr,indexAddr);
	writeTest();
//	build_Index();
//	readTest();
	close(fp_w);
	close(fp_r);
	return Py_BuildValue("");
}

static PyMethodDef invokeDBMethods[]={
	{"invokeDB", invokeDB, METH_VARARGS},
	{NULL, NULL, 0, NULL}
};

PyMODINIT_FUNC initmain(){
	Py_InitModule("main", invokeDBMethods);
}*/
