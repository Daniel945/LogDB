/*
 * var.c
 *
 *  Created on: Feb 17, 2014
 *      Author: hadoop
 */
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<sys/stat.h>
#include<unistd.h>
#include<fcntl.h>
#include<errno.h>
#include"main.h"

int INTERVAL = 1024;
int fp_w=-1, fp_r=-1;
const int headSize = 2*sizeof(int);

long long* index_key = NULL;
void** index_buf = NULL;

int keyType, valType;
//unsigned long index_filesize = -1;
int indexSize = 0;

int setup_flag = 0;
//int tim=0;

/*
void setup(const char* Daddr,const char* Iaddr,const char* keyType,const char* valType){
	setFilePath(Daddr);
	setIndexPath(Iaddr);
	setKeyType(keyType);
	setValueType(valType);
	if((fp_w = fopen(fileAddr,"ab")) == NULL){
		printf("cannot open this file: writer.");
		exit(0);
	}

	if((fp_r = fopen(fileAddr,"rb")) == NULL){
		printf("cannot open index file: reader.");
		exit(0);
	}

	fp_w = openFile(fileAddr);
	fp_r = openFile(fileAddr);
	readHead();
}
*/

void rewind_Read(){
	lseek(fp_r,headSize,SEEK_SET);
}
/*

void setInterval(int byte){
	INTERVAL = byte;
}
*/

int openFile(const char *file){
	int fd;
	fd = open(file, O_RDWR|O_CREAT, S_IRWXU);		// |O_CREAT|O_TRUNC  O_RDWR 可读可写； 第三个参数是mode，只在创建文件时用，I可执行R可读W可写
	if(fd==-1) printf("Fail to open:%m\n");
	return fd;
}

int openExistedFile(const char *file){
	int fd;
	fd = open(file, O_RDWR, S_IRWXU);		// |O_CREAT|O_TRUNC  O_RDWR 可读可写； 第三个参数是mode，只在创建文件时用，I可执行R可读W可写
	if(fd==-1) printf("Fail to open:%m\n");
	return fd;
}
