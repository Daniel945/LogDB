#include <Python.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "main.h"

static PyObject* quit(PyObject* self, PyObject* args){
	if(fp_w!=-1) close(fp_w);
	if(fp_r!=-1) close(fp_r);
	fp_w = -1;
	fp_r = -1;
	memset(fileAddr,'\0',100);
	memset(indexAddr,'\0',100);
	INTERVAL = 1024;

	int i;
	if(index_buf!=NULL) {
		for(i=0;i<indexSize;i++) free(index_buf[i]);
		free(index_buf);
		index_buf=NULL;
	}
	if(index_key!=NULL) {free(index_key);index_key=NULL;}
	indexSize = 0;
	setup_flag=0;
	Py_RETURN_NONE;
}

int setFilePath(char* path){
	if(path==NULL) {
		perror("filePath:Null value");
		printf("PLease set filePath again\n");
		return 1;
	}
	strcpy(fileAddr,path);
	return 0;
}

int setKeyType(const char* type){
	if(type==NULL) {
		perror("keyType:Null value");
		printf("PLease set keyType again\n");
		return 1;
	}
	if(strcasecmp(type,"INT")==0) keyType = INT;
	else if(strcasecmp(type,"DOUBLE")==0) keyType = DOUBLE;
	else if(strcasecmp(type,"STRING")==0) keyType = STRING;
	else{
		perror("keyType:Wrong input or system not support");
		printf("PLease set keyType again\n");
		return 1;
	}
	return 0;
}

int setValueType(const char* type){
	if(type==NULL) {
		perror("valueType:Null value");
		printf("PLease set valueType again\n");
		return 1;
	}
	if(strcasecmp(type,"INT")==0) valType = INT;
	else if(strcasecmp(type,"DOUBLE")==0) valType = DOUBLE;
	else if(strcasecmp(type,"STRING")==0) valType = STRING;
	else{
		perror("valueType:Wrong input or system not support");
		printf("PLease set valueType again\n");
		return 1;
	}
	return 0;
}

static PyObject* setup(PyObject* self, PyObject* args){
	PyObject* ww,*www;
	quit(ww,www);
	char *Daddr,*keyTypeT,*valTypeT;
	if(!PyArg_ParseTuple(args, "s|s|s", &Daddr,&keyTypeT,&valTypeT))
		return NULL;
	if(setFilePath(Daddr)) Py_RETURN_NONE;
	strcat(Daddr,"_index");
	if(setIndexPath(Daddr)) Py_RETURN_NONE;
	if(setKeyType(keyTypeT)) Py_RETURN_NONE;
	if(setValueType(valTypeT)) Py_RETURN_NONE;
	if((fp_w = openFile(fileAddr))==-1) Py_RETURN_NONE;
	if((fp_r = openFile(fileAddr))==-1) Py_RETURN_NONE;

	int length = lseek(fp_w,0,SEEK_END);
	if(length>0) {printf("File already exists\n");readHead();}
	else {
		lseek(fp_w,0,SEEK_SET);
		write(fp_w, &keyType, sizeof(int));
		write(fp_w, &valType, sizeof(int));
	}

	load_Index();
	INTERVAL = 1024;
	setup_flag=1;
	Py_RETURN_NONE;
}

static PyObject* setup_e(PyObject* self, PyObject* args){
	PyObject* ww,*www;
	quit(ww,www);

	char *Daddr;
	if(!PyArg_ParseTuple(args, "s", &Daddr))
		return NULL;

	if(setFilePath(Daddr)) Py_RETURN_NONE;
	char* Iaddr = strcat(Daddr,"_index");
	if(setIndexPath(Iaddr)) Py_RETURN_NONE;

	if((fp_w = openExistedFile(fileAddr))==-1) {printf("File not exists.\n");Py_RETURN_NONE;}
	if((fp_r = openExistedFile(fileAddr))==-1) {printf("File not exists.\n");Py_RETURN_NONE;}

	lseek(fp_w,0,SEEK_END);
	readHead();
	load_Index();
	INTERVAL = 1024;
	setup_flag=1;
	Py_RETURN_NONE;
}


static PyObject* setInterval(PyObject* self, PyObject* args){
	if(!setup_flag){printf("LogDB not setup.\n");Py_RETURN_NONE;}
	int byte;
	if(!PyArg_ParseTuple(args, "i", &byte))
		return NULL;
	INTERVAL = byte;
	Py_RETURN_NONE;
}

static PyObject* append(PyObject* self, PyObject* args){
	if(!setup_flag){printf("LogDB not setup.\n");Py_RETURN_NONE;}
	char format[4];
	char type[4]={'0','i','d','s'};
	format[1]='|';
	format[3]='\0';
	format[0]=type[keyType];
	format[2]=type[valType];

	void *a;int a1;double a2;
	void *b;int b1;double b2;
	void *var_a,*var_b;
	int a_len,b_len;

	switch(keyType){
		case INT: var_a=&a1;a_len=sizeof(int);break;
		case DOUBLE: var_a=&a2;a_len=sizeof(double);break;
		case STRING: var_a=&a;break;
		default: printf("keyType not correct.\n");Py_RETURN_NONE;
	}
	switch(valType){
		case INT: var_b=&b1;b_len=sizeof(int);break;
		case DOUBLE: var_b=&b2;b_len=sizeof(double);break;
		case STRING: var_b=&b;break;
		default: printf("valueType not correct.\n");Py_RETURN_NONE;
	}

	if(!PyArg_ParseTuple(args, format, var_a, var_b)){
		perror("Mismatched input dataType with existed dataFile.");
		return NULL;
	}

	if(keyType==STRING) a_len = strlen(a);
	if(valType==STRING) b_len =strlen(b);

	if((keyType==INT||keyType==DOUBLE)&&(valType==INT||valType==DOUBLE))
		_append(var_a,a_len,var_b,b_len);
	else if(keyType==STRING&&valType!=STRING) _append(a,a_len,var_b,b_len);
	else if(keyType!=STRING&&valType==STRING) _append(var_a,a_len,b,b_len);
	else _append(a,a_len,b,b_len);

	Py_RETURN_NONE;
}

static PyObject* search(PyObject* self, PyObject* args){
	if(!setup_flag){printf("LogDB not setup.\n");Py_RETURN_NONE;}

	char type[4]={'0','i','d','s'};
	char format[2],format_val[2];
	format[0] = type[keyType];
	format[1] = '\0';
	format_val[0] = type[valType];
	format_val[1] = '\0';

	void *a;int a1;double a2;
	char b[longestValue];
	memset(b,'\0',longestValue);
	void *var_a;

	switch(keyType){
		case INT: var_a=&a1;break;
		case DOUBLE: var_a=&a2;break;
		case STRING: var_a=&a;break;
		default: printf("keyType not correct.\n");Py_RETURN_NONE;
	}


	if(!PyArg_ParseTuple(args, format, var_a)){
		perror("Mismatched input dataType with existed dataFile.");
		return NULL;
	}

	int flag;
	if(keyType!=STRING) flag = _search(var_a,b);
	else flag = _search(a,b);
//	printf("%s\n%s\n",(char*)a,(char*)b);
	PyObject* obj;
	if(flag==0) Py_RETURN_NONE;
	switch(valType){
		case INT: obj = Py_BuildValue(format_val, *(int*)b);break;
		case DOUBLE: obj = Py_BuildValue(format_val, *(double*)b);break;
		case STRING: obj = Py_BuildValue(format_val, (char*)b);break;
	}

	return obj;
}

static PyObject* buildIndex(PyObject* self, PyObject* args){
	if(!setup_flag){printf("LogDB not setup.\n");Py_RETURN_NONE;}
	if(indexAddr!=NULL) build_Index();
	Py_RETURN_NONE;
}

static PyObject* loadIndex(PyObject* self, PyObject* args){
	if(!setup_flag){printf("LogDB not setup.\n");Py_RETURN_NONE;}
	load_Index();
	Py_RETURN_NONE;
}



static PyMethodDef addMethods[]={
	{"setup", setup, METH_VARARGS},
	{"setup_e", setup_e, METH_VARARGS},
	{"setInterval", setInterval, METH_VARARGS},
	{"append", append, METH_VARARGS},
	{"search", search, METH_VARARGS},
	{"buildIndex",buildIndex,METH_VARARGS},
	{"loadIndex",loadIndex,METH_VARARGS},
	{"quit",quit,METH_VARARGS},
	{NULL, NULL, 0, NULL}
};



PyMODINIT_FUNC initLogDB(){
	Py_InitModule("LogDB", addMethods);
}
