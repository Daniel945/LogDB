#include<string.h>
#include<stdlib.h>
#include<sys/stat.h>
#include<unistd.h>
#include<fcntl.h>
#include<errno.h>
#include<stdio.h>
#include"main.h"

int setIndexPath(const char* path){
	if(strlen(path)==0) {
		perror("indexPath:Empty value");
		printf("PLease set indexPath again\n");
		return 1;
	}
	strcpy(indexAddr,path);
	return 0;
}

int build_Index(){
	int fp;
	int fp_data;

	fp = open(indexAddr, O_RDWR|O_CREAT|O_TRUNC, S_IRWXU);		// |O_CREAT|O_TRUNC  O_RDWR 可读可写； 第三个参数是mode，只在创建文件时用，I可执行R可读W可写
	if(fp==-1) printf("open error :%m\n");

	fp_data = open(fileAddr, O_RDONLY);
	if(fp_data==-1) printf("open error :%m\n");

	cont_start(fp_data);

	int keySize;
	int pairSize;
	long long offset = headSize;
	int cur_Size = 0;
	char key[longestValue]={'\0'};
	char value[longestValue]={'\0'};

	int record_Num = 0; 					/**************/
	lseek(fp,sizeof(int),SEEK_SET);			/**************/
	int ret;
	while(1){
//		util_next(key,value,&keySize,&pairSize);
		ret = read(fp_data,&pairSize, sizeof(int));
		ret = read(fp_data,&keySize, sizeof(int));
		ret = read(fp_data,key, keySize);
		ret = read(fp_data,value, pairSize - keySize);
		if(-1==ret||0==ret) break;
//		if(feof(fp_data)) break;

		if(cur_Size/INTERVAL>0 || cur_Size == 0){
			cur_Size = 0;
			record_Num++;
			write(fp,&keySize,sizeof(int));
			write(fp,key, keySize);
			write(fp,&offset, sizeof(long long));
//			printf("offset:%lld\n",offset);
		}

		offset+=pairSize+8;
		cur_Size+=pairSize;
	}

	lseek(fp,0,SEEK_SET);
	write(fp,&record_Num,sizeof(int));
/*
	rewind(fp);
	int keyG;//change to test

	int record;
	fread(&record,sizeof(int),1,fp);
	printf("%i\n",record);

	while(1){
		fread(&keySize,sizeof(int),1,fp);
		fread(&keyG, keySize, 1, fp);
		fread(&offset, sizeof(int),1,fp);
		if(feof(fp)) break;
		printf("%i %i \n", keyG, offset);//change to test
	}*/
	close(fp);
	close(fp_data);
	return 1;
}

int load_Index(){
//	unsigned long filesize = -1;
/*	struct stat statbuff;
	if(stat(indexAddr, &statbuff) < 0){
		return index_filesize;
	}else{
		index_filesize = statbuff.st_size;
	}
*/
	int fp;
	fp = open(indexAddr,O_CREAT|O_RDWR, S_IRWXU);		// |O_CREAT|O_TRUNC  O_RDWR 可读可写； 第三个参数是mode，只在创建文件时用，I可执行R可读W可写
	if(fp==-1) printf("open error :%m\n");

	int fp_size = lseek(fp,0,SEEK_END);
	if(fp_size==0){close(fp);return 1;}

	lseek(fp,0,SEEK_SET);
	read(fp,&indexSize,sizeof(int));

	index_buf = (void**)malloc(indexSize*sizeof(void**));
	index_key = malloc(indexSize*sizeof(long long));
	int i,keySize;
	for(i=0;i<indexSize;i++){
		read(fp,&keySize,sizeof(int));
		index_buf[i] = malloc(keySize);
		read(fp,index_buf[i],keySize);
		read(fp,&index_key[i],sizeof(long long));
//		printf("offset:%lld\n",index_key[i]);
	}

/*	index_buf = malloc(index_filesize+1);
	if(index_buf == NULL) return 0;
	fread(index_buf,index_filesize,1,fp);*/
/*
	char key[50]={'\0'};
	int keySize, offset,buf_offset=0;
	while(1){
		memcpy(&keySize,index_buf+buf_offset,sizeof(int));
		buf_offset+=sizeof(int);
		memcpy(key,index_buf+buf_offset,keySize);
		buf_offset+=keySize;
		memcpy(&offset,index_buf+buf_offset,4);
		if(buf_offset>=index_filesize) break;
		buf_offset+=4;
		printf("%s %i \n", key, offset);
	}*/
	close(fp);
	return 1;

}
