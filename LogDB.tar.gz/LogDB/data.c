/*
 * data.c
 *
 *  Created on: Feb 10, 2014
 *      Author: hadoop
 */
#include<string.h>
#include<stdlib.h>
#include<stdio.h>
#include"main.h"
#include<sys/time.h>
#include<sys/stat.h>
#include<unistd.h>


void readHead(){
	read(fp_r,&keyType,sizeof(int));
	read(fp_r,&valType,sizeof(int));
}

void cont_start(const int fp){
	lseek(fp,headSize,SEEK_SET);
}

int _append(void* key,int keySize,void* value,int valueSize){
//	checkType(key, value);
	int pairSize = keySize + valueSize;
	int ret;
	ret = write(fp_w,&pairSize, sizeof(int));
	ret = write(fp_w,&keySize, sizeof(int));
	ret = write(fp_w, key, keySize);
	ret = write(fp_w, value, valueSize);
	return ret;
}

int _next(void* key, void* value){
	int keySize;
	int pairSize;
	int ret;
//	if(feof(fp_r)) return 0;
	ret = read(fp_r,&pairSize, sizeof(int));
	ret = read(fp_r,&keySize, sizeof(int));
	ret = read(fp_r,key, keySize);
	ret = read(fp_r,value, pairSize - keySize);

	return ret;
}

int util_next(void* key, void* value ,int* keySize, int* pairSize){
//	if(feof(fp_r)) return 0;
	int ret;
	read(fp_r,pairSize, sizeof(int));
	read(fp_r,keySize, sizeof(int));
	read(fp_r,key, *keySize);
	ret = read(fp_r,value, *pairSize - *keySize);
	return ret>0;
}

/*int _get(void* key, void* value){			//可以在宏加入获取key大小和value大小的变量，获得
//	checkType(key, value);
	char tmpKey[50]={'\0'};
	char tmpVal[50]={'\0'};
	int keyS,pairS;
	cont_start(fp_r);
	printf("start\n");
	while(util_next(tmpKey,tmpVal,&keyS,&pairS) > 0){
		printf("%i %i %s\n",*(int*)key,*(int*)tmpKey,tmpVal);
		if(memcmp(tmpKey,key,keyS) == 0){
			printf("Inside: %i %s\n",*(int*)tmpKey,tmpVal);
			memcpy(value,tmpVal,pairS);
			return 1;
		}
	}
	return 0;
}*/

int compare(void* mid, void* key){
	double result;
	if(keyType==DOUBLE)
		result = *(double*)mid-*(double*)key;
	else if(keyType==INT)
		result = *(int*)mid-*(int*)key;
	else
		result = strcmp(mid,key);

	if(result<0) return -1;
	else if(result>0) return 1;
	else return 0;
}

void find(void* key, long long* offset){
/*		struct timeval startA,endA;
		long long cost;
		gettimeofday(&startA,NULL);*/
	int start=0,end=indexSize-1,mid=(start+end)/2;
	int cmp;
//	int i=0;
	while(start<=end){
//		printf("start:%i mid:%i end:%i time:%i key:%i\n",start,mid,end,++i,*(int*)key);
		cmp = compare(index_buf[mid],key);
		if(cmp<0)  start = mid+1;
		else if(cmp>0) end = mid-1;
		else {*offset = index_key[mid];return;}
		mid=(start+end)/2;
	}

	if(end>=0) *offset = index_key[end];
	else{
		if(index_key==NULL||indexSize==0) *offset = headSize;
		else *offset = index_key[start];
	}
	/*	gettimeofday(&endA,NULL);
		cost = ((long long)1000000*endA.tv_sec+endA.tv_usec) - ((long long)1000000*startA.tv_sec+startA.tv_usec);
		printf("find %lld\n",cost);*/
}

int _search(void* key, void* value){
	long long offset;
	find(key,&offset);						//找到Index文件中的对应的offset
//	offsetFu[tim]=offset;
//	tim++;

//	rewind(fp_r);
//	int times = offset/LONG_MAX;					//找到DATA文件中对应的位置，下面开始逐个查找
//	long remaider = offset%LONG_MAX;
//	int t;
//	for(t=0;t<times;t++){fseek(fp_r,LONG_MAX,SEEK_CUR);}

	lseek(fp_r,offset,SEEK_SET);

	char tmp[longestValue]={'\0'};
	char tmpVal[longestValue]={'\0'};

	int keyS,pairS;
	/*				struct timeval start,end;
					long long cost;
					gettimeofday(&start,NULL);
					int count=0;*/
	int flag=1;
	while((flag=util_next(tmp,tmpVal,&keyS,&pairS))){
		if( memcmp(tmp,key,keyS)==0 ){
			memcpy(value,tmpVal,pairS-keyS);
			break;
		}
		if(compare(tmp,key)>0) {flag=0;break;}
	//	count++;
	}
	//					gettimeofday(&end,NULL);
	//					cost = ((long long)1000000*end.tv_sec+end.tv_usec) - ((long long)1000000*start.tv_sec+start.tv_usec);
	//					printf("%i %lld\n",count,cost);

	return flag;
}
